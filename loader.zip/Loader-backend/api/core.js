const fs = require('fs');
const path = require('path');

module.exports = (req, res) => {
  try {
    // Membaca file script dari folder public/script.js
    const filePath = path.join(process.cwd(), 'public', 'script.js');
    const coreCode = fs.readFileSync(filePath, 'utf8');

    // Mengirimkan response berformat JavaScript
    res.setHeader('Content-Type', 'application/javascript; charset=utf-8');
    res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate');
    res.status(200).send(coreCode);
  } catch (error) {
    res.status(500).send('Gagal membaca file core: ' + error.message);
  }
};
